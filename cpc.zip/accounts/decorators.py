from functools import wraps

from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied


def grupos_requeridos(*nombres_grupo):
    """
    Restringe una vista a usuarios autenticados que pertenezcan a uno de los
    grupos indicados. Los superusuarios siempre tienen acceso.

    Se usa para que los permisos del backend coincidan con los módulos visibles
    en el menú, evitando acceso directo por URL a módulos no autorizados.
    """
    nombres_grupo = tuple(nombres_grupo)

    def decorator(view_func):
        @wraps(view_func)
        @login_required
        def _wrapped_view(request, *args, **kwargs):
            user = request.user
            if user.is_superuser:
                return view_func(request, *args, **kwargs)
            if nombres_grupo and user.groups.filter(name__in=nombres_grupo).exists():
                return view_func(request, *args, **kwargs)
            raise PermissionDenied

        return _wrapped_view

    return decorator


def administrador_requerido(view_func):
    """Restringe una vista a superusuarios o usuarios del grupo Administrador."""
    return grupos_requeridos("Administrador")(view_func)
